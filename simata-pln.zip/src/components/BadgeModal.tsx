/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef } from 'react';
import { X, Printer, Shield, Eye, Flame, CheckCircle, Smartphone } from 'lucide-react';
import { Visitor } from '../types';
import PLNLogo from './PLNLogo';

interface BadgeModalProps {
  visitor: Visitor | null;
  onClose: () => void;
}

export default function BadgeModal({ visitor, onClose }: BadgeModalProps) {
  if (!visitor) return null;

  const badgeRef = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    // Elegant mock printing: tells user badge is ready and opens window print preview or prints styled area
    const printContent = badgeRef.current?.innerHTML;
    const originalContent = document.body.innerHTML;

    if (printContent) {
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(`
          <html>
            <head>
              <title>Cetak Pass Tamu - ${visitor.visitorName}</title>
              <script src="https://cdn.tailwindcss.com"></script>
              <style>
                @media print {
                  body { padding: 2cm; background: white; color: black; }
                  .no-print { display: none; }
                }
              </style>
            </head>
            <body class="bg-gray-100 flex items-center justify-center min-h-screen">
              <div class="p-6 bg-white border border-slate-300 rounded-2xl w-[400px] shadow-lg">
                ${printContent}
              </div>
              <script>
                window.onload = function() {
                  window.print();
                  setTimeout(() => window.close(), 1000);
                }
              </script>
            </body>
          </html>
        `);
        printWindow.document.close();
      }
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
      <div className="bg-white dark:bg-[#111c30] rounded-none max-w-md w-full shadow-2xl overflow-hidden border-2 border-[#005DA6]">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b-2 border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2 text-[#005DA6] dark:text-[#FFD500]">
            <Shield size={20} />
            <h3 className="font-bold text-slate-800 dark:text-white font-display uppercase text-xs tracking-wider">Kartu Masuk Tamu Digital</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-none text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Badge Render Area */}
        <div className="p-6 bg-slate-50 dark:bg-slate-950 flex flex-col items-center">
          
          <div
            ref={badgeRef}
            className="w-full bg-white dark:bg-slate-900 border-2 border-dashed border-[#005DA6] rounded-none p-6 shadow-sm relative overflow-hidden"
          >
            {/* Background watermarks for safety */}
            <div className="absolute inset-0 bg-[radial-gradient(#005da6_1px,transparent_1px)] [background-size:16px_16px] opacity-5 pointer-events-none"></div>
            
            {/* PLN Header */}
            <div className="flex items-center justify-between border-b pb-4 mb-4 border-slate-100 dark:border-slate-800">
              <PLNLogo size="sm" showText={true} />
              <div className="text-right">
                <span className="inline-block px-2 py-0.5 text-[8px] font-bold text-rose-600 bg-rose-50 border border-rose-100 rounded-none dark:bg-rose-950/20 dark:border-rose-900 font-sans">
                  SECURE PASS
                </span>
                <p className="font-mono text-[9px] font-medium text-slate-400 mt-1 uppercase">
                  {visitor.id}
                </p>
              </div>
            </div>

            {/* Main Pass Type visual belt */}
            <div className="bg-[#005DA6] text-[#FFD500] text-center py-1.5 px-3 rounded-none font-black text-sm tracking-widest uppercase mb-4 border-b border-[#FFD500]">
              VISITOR / TAMU
            </div>

            {/* Visitor Identity Details */}
            <div className="space-y-3.5 text-center my-4 font-sans">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Nama Lengkap</span>
                <p className="font-sans font-black text-lg text-slate-900 dark:text-white tracking-tight leading-tight uppercase mt-0.5">
                  {visitor.visitorName}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-1 border-t border-slate-100 dark:border-slate-800/80">
                <div>
                  <span className="text-[9px] uppercase font-bold text-slate-400 tracking-wider">Instansi/Perusahaan</span>
                  <p className="text-xs font-bold text-slate-700 dark:text-slate-300 mt-0.5 truncate uppercase">
                    {visitor.company}
                  </p>
                </div>
                <div>
                  <span className="text-[9px] uppercase font-bold text-slate-400 tracking-wider">Tujuan Kunjungan</span>
                  <p className="text-xs font-bold text-slate-700 dark:text-slate-300 mt-0.5 truncate capitalize">
                    {visitor.purpose}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-1">
                <div>
                  <span className="text-[9px] uppercase font-bold text-slate-400 tracking-wider">Bertemu</span>
                  <p className="text-xs font-bold text-[#005DA6] dark:text-[#FFD500] mt-0.5 truncate uppercase">
                    {visitor.visited}
                  </p>
                </div>
                <div>
                  <span className="text-[9px] uppercase font-bold text-slate-400 tracking-wider">Main Gate Pass</span>
                  <p className="text-xs font-mono font-bold text-amber-600 dark:text-amber-500 mt-0.5 truncate">
                    {visitor.mainGatePass || '-'}
                  </p>
                </div>
              </div>

              <div className="pt-2 text-center border-t border-slate-100 dark:border-slate-800/80">
                <span className="text-[9px] uppercase font-bold text-slate-400 tracking-wider">Waktu Masuk</span>
                <p className="text-xs font-mono font-semibold text-slate-700 dark:text-slate-300 mt-0.5">
                  {visitor.inTime || visitor.schedule || 'Belum Check-In'}
                </p>
              </div>
            </div>

            {/* Simulated Digital QR block & Barcode */}
            <div className="flex flex-col items-center justify-center bg-slate-50 dark:bg-slate-950 p-4 rounded-none border border-slate-100 dark:border-slate-850 mt-4 gap-2">
              <div className="relative p-2 bg-white rounded-none border border-slate-200">
                {/* 2D QR Pattern block using beautiful layout */}
                <div className="w-24 h-24 bg-slate-900 p-1 rounded-none flex flex-col justify-between overflow-hidden">
                  {/* Grid of black/white blocks simulating a real QR */}
                  <div className="grid grid-cols-5 gap-1.5 h-full w-full">
                    <div className="bg-white rounded-none"></div><div className="bg-white rounded-none"></div><div className="bg-slate-900"></div><div className="bg-white rounded-none"></div><div className="bg-white rounded-none"></div>
                    <div className="bg-white rounded-none"></div><div className="bg-slate-900"></div><div className="bg-white rounded-none"></div><div className="bg-slate-900"></div><div className="bg-white rounded-none"></div>
                    <div className="bg-slate-900"></div><div className="bg-white rounded-none"></div><div className="bg-[#FFD500] flex items-center justify-center font-bold text-[8px] text-slate-900">⚡</div><div className="bg-white rounded-none"></div><div className="bg-slate-900"></div>
                    <div className="bg-white rounded-none"></div><div className="bg-slate-900"></div><div className="bg-white rounded-none"></div><div className="bg-slate-900"></div><div className="bg-white rounded-none"></div>
                    <div className="bg-white rounded-none"></div><div className="bg-white rounded-none"></div><div className="bg-slate-900"></div><div className="bg-white rounded-none"></div><div className="bg-white rounded-none"></div>
                  </div>
                </div>
              </div>
              <div className="text-center">
                <span className="text-[7px] font-mono text-slate-400 tracking-widest block">
                  GEN-SECURE-KEY-{visitor.id.replace('TJB-VST-', '')}-PLN
                </span>
                <span className="text-[9px] text-[#005DA6] dark:text-[#FFD500] font-bold flex items-center justify-center gap-1 mt-0.5 uppercase tracking-wider">
                  <span className="inline-block w-1.5 h-1.5 bg-emerald-500 rounded-none animate-pulse"></span>
                  Valid QR Scanner
                </span>
              </div>
            </div>

            {/* Guard Warning notice */}
            <div className="mt-4 text-[8px] text-slate-400 text-center uppercase tracking-wide leading-normal">
              * Harap dikalungkan selama berada di lingkungan PT PLN (Persero).
              Kembalikan ke Sekretariat / Pos Penjagaan saat Check-Out.
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="p-4 bg-slate-100 dark:bg-slate-800/40 flex gap-3 border-t-2 border-slate-100 dark:border-slate-850">
          <button
            onClick={handlePrint}
            className="flex-1 py-2.5 px-4 bg-[#005DA6] hover:bg-[#004070] active:bg-[#003056] text-white rounded-none font-bold flex items-center justify-center gap-2 text-sm border-b-2 border-r-2 border-[#FFD500] cursor-pointer"
          >
            <Printer size={16} />
            Cetak Pas Masuk
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2.5 bg-white dark:bg-[#111c30] hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-none font-semibold text-sm border border-slate-200 dark:border-slate-700 transition-all cursor-pointer"
          >
            Tutup
          </button>
        </div>
        
      </div>
    </div>
  );
}
