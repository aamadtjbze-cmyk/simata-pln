/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Search,
  Check,
  Trash2,
  Lock,
  ExternalLink,
  Printer,
  ChevronUp,
  ChevronDown,
  RefreshCw,
  SlidersHorizontal,
  Calendar,
  Layers,
  CheckSquare,
  UserCheck2,
  Eye,
  AlertTriangle,
  Users2
} from 'lucide-react';
import { Visitor, VisitorStatus } from '../types';

interface VisitorTableProps {
  visitors: Visitor[];
  onCheckOut: (visitorId: string) => void;
  onCheckOutBatch: (visitorIds: string[]) => void;
  onEdit: (visitor: Visitor) => void;
  onDelete: (visitorId: string) => void;
  onViewBadge: (visitor: Visitor) => void;
  onAddSampleData: () => void;
}

type SortField = 'id' | 'schedule' | 'inTime' | 'outTime' | 'visitorName' | 'company' | 'purpose' | 'visited' | 'status';

export default function VisitorTable({
  visitors,
  onCheckOut,
  onCheckOutBatch,
  onEdit,
  onDelete,
  onViewBadge,
  onAddSampleData
}: VisitorTableProps) {
  // Filtering states
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<VisitorStatus | 'ALL'>('ALL');
  const [filterPurpose, setFilterPurpose] = useState('ALL');
  const [scheduleFilter, setScheduleFilter] = useState('');
  const [inFilter, setInFilter] = useState('');
  const [outFilter, setOutFilter] = useState('');

  // Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const [entriesPerPage, setEntriesPerPage] = useState(10);

  // Sorting states
  const [sortField, setSortField] = useState<SortField>('id');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');

  // Multi-select row state
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  // Unique companies / purposes for dropdown filters
  const uniquePurposes = Array.from(new Set(visitors.map((v) => v.purpose))).filter(Boolean);

  // Sorting logic helper
  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  // Selection helpers
  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      const pageItems = currentPagedItems.map((item) => item.id);
      setSelectedIds(Array.from(new Set([...selectedIds, ...pageItems])));
    } else {
      const pageItems = currentPagedItems.map((item) => item.id);
      setSelectedIds(selectedIds.filter((id) => !pageItems.includes(id)));
    }
  };

  const handleSelectRow = (id: string, checked: boolean) => {
    if (checked) {
      setSelectedIds([...selectedIds, id]);
    } else {
      setSelectedIds(selectedIds.filter((rowId) => rowId !== id));
    }
  };

  // Confirm by group batch check-out
  const handleConfirmByGroup = () => {
    if (selectedIds.length === 0) return;
    const inProgressSelected = visitors
      .filter((v) => selectedIds.includes(v.id) && v.status === 'IN-PROGRESS')
      .map((v) => v.id);

    if (inProgressSelected.length === 0) {
      alert('Tidak ada tamu berstatus IN-PROGRESS pilihan Anda yang perlu diCheck-Out.');
      return;
    }

    if (confirm(`Check-Out ${inProgressSelected.length} tamu terpilih sekaligus?`)) {
      onCheckOutBatch(inProgressSelected);
      setSelectedIds([]);
    }
  };

  // Reset filters
  const handleClearFilters = () => {
    setSearch('');
    setFilterStatus('ALL');
    setFilterPurpose('ALL');
    setScheduleFilter('');
    setInFilter('');
    setOutFilter('');
    setCurrentPage(1);
  };

  // Filter & Search Logic
  const filteredItems = visitors.filter((item) => {
    // General text search
    const matchesSearch =
      item.visitorName.toLowerCase().includes(search.toLowerCase()) ||
      item.id.toLowerCase().includes(search.toLowerCase()) ||
      item.company.toLowerCase().includes(search.toLowerCase()) ||
      item.visited.toLowerCase().includes(search.toLowerCase()) ||
      item.purpose.toLowerCase().includes(search.toLowerCase());

    // Filter statuses
    const matchesStatus = filterStatus === 'ALL' || item.status === filterStatus;

    // Filter purposes
    const matchesPurpose = filterPurpose === 'ALL' || item.purpose === filterPurpose;

    // Filter Schedule Date
    const matchesScheduleFilter =
      !scheduleFilter ||
      item.schedule.toLowerCase().includes(scheduleFilter.toLowerCase());

    // Filter IN Date
    const matchesInFilter =
      !inFilter ||
      (item.inTime && item.inTime.toLowerCase().includes(inFilter.toLowerCase()));

    // Filter OUT Date
    const matchesOutFilter =
      !outFilter ||
      (item.outTime && item.outTime.toLowerCase().includes(outFilter.toLowerCase()));

    return (
      matchesSearch &&
      matchesStatus &&
      matchesPurpose &&
      matchesScheduleFilter &&
      matchesInFilter &&
      matchesOutFilter
    );
  });

  // Sorting Process
  const sortedItems = [...filteredItems].sort((a, b) => {
    let valA = a[sortField] || '';
    let valB = b[sortField] || '';

    // Handle string comparisons
    if (typeof valA === 'string' && typeof valB === 'string') {
      return sortDirection === 'asc'
        ? valA.localeCompare(valB)
        : valB.localeCompare(valA);
    }
    return 0;
  });

  // Pagination bounds
  const totalEntries = sortedItems.length;
  const indexOfLastItem = currentPage * entriesPerPage;
  const indexOfFirstItem = indexOfLastItem - entriesPerPage;
  const currentPagedItems = sortedItems.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(totalEntries / entriesPerPage) || 1;

  // Change page helper
  const handlePageChange = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  const getStatusBadge = (status: VisitorStatus) => {
    switch (status) {
      case 'DONE':
        return (
          <span className="inline-flex items-center px-2 py-1 rounded-none text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-100 dark:bg-emerald-950/20 dark:text-emerald-400 dark:border-emerald-900 font-sans">
            DONE
          </span>
        );
      case 'IN-PROGRESS':
        return (
          <span className="inline-flex items-center px-2 py-1 rounded-none text-xs font-bold bg-amber-50 text-amber-600 border border-amber-100 dark:bg-amber-950/20 dark:text-amber-400 dark:border-amber-900 animate-pulse font-sans">
            IN-PROGRESS
          </span>
        );
      case 'SCHEDULED':
        return (
          <span className="inline-flex items-center px-2 py-1 rounded-none text-xs font-bold bg-sky-50 text-sky-600 border border-sky-100 dark:bg-sky-950/20 dark:text-sky-400 dark:border-sky-900 font-sans">
            SCHEDULED
          </span>
        );
      case 'PENDING':
        return (
          <span className="inline-flex items-center px-2 py-1 rounded-none text-xs font-bold bg-slate-100 text-slate-600 border border-slate-200 dark:bg-slate-850 dark:text-slate-400 dark:border-slate-800 font-sans">
            PENDING
          </span>
        );
    }
  };

  const isAllPageSelected =
    currentPagedItems.length > 0 &&
    currentPagedItems.every((item) => selectedIds.includes(item.id));

  return (
    <div className="bg-white dark:bg-[#111c30] border-2 border-slate-200 dark:border-[#005DA6] rounded-none overflow-hidden shadow-md w-full flex flex-col">
      
      {/* Top Filter Toolbar */}
      <div className="p-5 border-b-2 border-slate-200 dark:border-slate-800 flex flex-col md:flex-row gap-4 items-stretch md:items-center justify-between bg-slate-50 dark:bg-slate-950">
        
        {/* Search query input */}
        <div className="relative flex-1 max-w-md">
          <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
            <Search size={18} />
          </span>
          <input
            type="text"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setCurrentPage(1);
            }}
            placeholder="Cari nama, instansi, form ID, atau pegawai..."
            className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-[#152033] border border-slate-200 dark:border-slate-850 rounded-none text-slate-800 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#005DA6] focus:border-[#005DA6] font-semibold"
          />
        </div>

        {/* Toolbar Controls */}
        <div className="flex flex-wrap items-center gap-3">
          
          {/* Status filter dropdown */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-500 hidden xl:inline">Status:</span>
            <select
              value={filterStatus}
              onChange={(e) => {
                setFilterStatus(e.target.value as any);
                setCurrentPage(1);
              }}
              className="py-2.5 pl-3 pr-8 bg-white dark:bg-[#152033] border border-slate-200 dark:border-slate-800 rounded-none text-slate-700 dark:text-slate-300 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-[#005DA6]"
            >
              <option value="ALL">Semua Status</option>
              <option value="IN-PROGRESS">IN-PROGRESS</option>
              <option value="DONE">DONE / Keluar</option>
              <option value="SCHEDULED">SCHEDULED / Janji</option>
              <option value="PENDING">PENDING</option>
            </select>
          </div>

          {/* Purpose dropdown */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-500 hidden xl:inline">Tujuan:</span>
            <select
              value={filterPurpose}
              onChange={(e) => {
                setFilterPurpose(e.target.value);
                setCurrentPage(1);
              }}
              className="py-2.5 pl-3 pr-8 bg-white dark:bg-[#152033] border border-slate-200 dark:border-slate-800 rounded-none text-slate-700 dark:text-slate-300 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-[#005DA6]"
            >
              <option value="ALL">Semua Tujuan</option>
              {uniquePurposes.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={handleClearFilters}
            title="Reset Filters"
            className="p-2.5 hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400 rounded-none transition-all border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#152033]"
          >
            <RefreshCw size={16} />
          </button>

          {/* Confirm by Group */}
          <button
            onClick={handleConfirmByGroup}
            disabled={selectedIds.length === 0}
            className={`py-2.5 px-4 rounded-none text-xs font-bold transition-all flex items-center gap-1.5 border-b-2 border-r-2 ${
              selectedIds.length > 0
                ? 'bg-[#005DA6] text-[#FFD500] border-[#FFD500] hover:bg-[#004070] cursor-pointer'
                : 'bg-slate-100 dark:bg-slate-800/80 text-slate-400 dark:text-slate-600 border-transparent cursor-not-allowed'
            }`}
          >
            <CheckSquare size={15} />
            Confirm By Group ({selectedIds.length})
          </button>

        </div>
      </div>

      {/* Sorting Indicators Info Bar (Mobile helper) */}
      <div className="px-5 py-2.5 bg-slate-100/50 dark:bg-slate-900/50 flex flex-wrap justify-between items-center text-[10px] text-slate-400 border-b border-slate-100 dark:border-slate-800">
        <div className="flex gap-4">
          <span>Menampilkan hasil pencarian: <strong>{totalEntries}</strong> entries</span>
          {selectedIds.length > 0 && (
            <span className="text-amber-600 font-bold">Terpilih {selectedIds.length} baris untuk tindakan kelompok</span>
          )}
        </div>
        <div className="hidden sm:block">
          Klik nama kolom tabel untuk mengurutkan data tamu
        </div>
      </div>

      {/* Table Canvas */}
      <div className="overflow-auto flex-1 min-h-0 w-full">
        <table className="min-w-[1250px] w-full text-left border-collapse">
          <thead>
            {/* Main Header Labels */}
            <tr className="bg-slate-100 dark:bg-slate-950/60 border-b border-slate-200 dark:border-slate-800/50 text-[11px] font-bold text-slate-600 dark:text-slate-300 uppercase tracking-wider select-none">
              
              <th className="p-4 w-12 text-center">
                <input
                  type="checkbox"
                  checked={isAllPageSelected}
                  onChange={handleSelectAll}
                  className="rounded-none accent-[#005DA6] w-4 h-4 cursor-pointer"
                />
              </th>

              <th
                onClick={() => handleSort('id')}
                className="p-4 cursor-pointer hover:bg-slate-200/50 dark:hover:bg-slate-800/50 transition-all font-mono w-40"
              >
                <div className="flex items-center gap-1">
                  Form ID
                  {sortField === 'id' && (sortDirection === 'asc' ? <ChevronUp size={12} /> : <ChevronDown size={12} />)}
                </div>
              </th>

              <th
                onClick={() => handleSort('schedule')}
                className="p-4 cursor-pointer hover:bg-slate-200/50 dark:hover:bg-slate-800/50 transition-all"
              >
                <div className="flex items-center gap-1">
                  Schedule
                  {sortField === 'schedule' && (sortDirection === 'asc' ? <ChevronUp size={12} /> : <ChevronDown size={12} />)}
                </div>
              </th>

              <th
                onClick={() => handleSort('inTime')}
                className="p-4 cursor-pointer hover:bg-slate-200/50 dark:hover:bg-slate-800/50 transition-all"
              >
                <div className="flex items-center gap-1">
                  IN
                  {sortField === 'inTime' && (sortDirection === 'asc' ? <ChevronUp size={12} /> : <ChevronDown size={12} />)}
                </div>
              </th>

              <th
                onClick={() => handleSort('outTime')}
                className="p-4 cursor-pointer hover:bg-slate-200/50 dark:hover:bg-slate-800/50 transition-all"
              >
                <div className="flex items-center gap-1">
                  OUT
                  {sortField === 'outTime' && (sortDirection === 'asc' ? <ChevronUp size={12} /> : <ChevronDown size={12} />)}
                </div>
              </th>

              <th
                onClick={() => handleSort('visitorName')}
                className="p-4 cursor-pointer hover:bg-slate-200/50 dark:hover:bg-slate-800/50 transition-all"
              >
                <div className="flex items-center gap-1">
                  Visitor
                  {sortField === 'visitorName' && (sortDirection === 'asc' ? <ChevronUp size={12} /> : <ChevronDown size={12} />)}
                </div>
              </th>

              <th className="p-4">Gate Pass</th>

              <th
                onClick={() => handleSort('company')}
                className="p-4 cursor-pointer hover:bg-slate-200/50 dark:hover:bg-slate-800/50 transition-all"
              >
                <div className="flex items-center gap-1">
                  Company
                  {sortField === 'company' && (sortDirection === 'asc' ? <ChevronUp size={12} /> : <ChevronDown size={12} />)}
                </div>
              </th>

              <th
                onClick={() => handleSort('purpose')}
                className="p-4 cursor-pointer hover:bg-slate-200/50 dark:hover:bg-slate-800/50 transition-all text-xs"
              >
                <div className="flex items-center gap-1 text-slate-550">
                  Purpose
                  {sortField === 'purpose' && (sortDirection === 'asc' ? <ChevronUp size={12} /> : <ChevronDown size={12} />)}
                </div>
              </th>

              <th
                onClick={() => handleSort('visited')}
                className="p-4 cursor-pointer hover:bg-slate-200/50 dark:hover:bg-slate-800/50 transition-all"
              >
                <div className="flex items-center gap-1">
                  Visited
                  {sortField === 'visited' && (sortDirection === 'asc' ? <ChevronUp size={12} /> : <ChevronDown size={12} />)}
                </div>
              </th>

              <th
                onClick={() => handleSort('status')}
                className="p-4 cursor-pointer hover:bg-slate-200/50 dark:hover:bg-slate-800/50 transition-all text-center"
              >
                <div className="flex items-center justify-center gap-1">
                  Status
                  {sortField === 'status' && (sortDirection === 'asc' ? <ChevronUp size={12} /> : <ChevronDown size={12} />)}
                </div>
              </th>

              <th className="p-4 text-center">Aksi</th>
            </tr>

            {/* Column Date Filter Inputs (Directly modeled after image) */}
            <tr className="bg-slate-50 dark:bg-slate-950/20 border-b border-slate-200 dark:border-slate-800/80 font-mono text-[10px]">
              <td className="p-2 border-r border-slate-100 dark:border-slate-800"></td>
              <td className="p-2 border-r border-slate-100 dark:border-slate-800"></td>
              
              {/* Schedule date search input */}
              <td className="p-1 px-2 border-r border-slate-100 dark:border-slate-800">
                <div className="relative">
                  <input
                    type="text"
                    value={scheduleFilter}
                    onChange={(e) => setScheduleFilter(e.target.value)}
                    placeholder="dd/mm/yyyy"
                    className="w-full text-[10px] px-2 py-1 bg-white dark:bg-[#152033] border border-slate-200 dark:border-slate-800 rounded-none text-slate-800 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-[#005DA6] placeholder-slate-400"
                  />
                </div>
              </td>

              {/* IN date search input */}
              <td className="p-1 px-2 border-r border-slate-100 dark:border-slate-800">
                <div className="relative">
                  <input
                    type="text"
                    value={inFilter}
                    onChange={(e) => setInFilter(e.target.value)}
                    placeholder="dd/mm/yyyy"
                    className="w-full text-[10px] px-2 py-1 bg-white dark:bg-[#152033] border border-slate-200 dark:border-slate-800 rounded-none text-slate-800 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-[#005DA6] placeholder-slate-400"
                  />
                </div>
              </td>

              {/* OUT date search input */}
              <td className="p-1 px-2 border-r border-slate-100 dark:border-slate-800">
                <div className="relative">
                  <input
                    type="text"
                    value={outFilter}
                    onChange={(e) => setOutFilter(e.target.value)}
                    placeholder="dd/mm/yyyy"
                    className="w-full text-[10px] px-2 py-1 bg-white dark:bg-[#152033] border border-slate-200 dark:border-slate-800 rounded-none text-slate-800 dark:text-slate-300 focus:outline-none focus:ring-2 focus:ring-[#005DA6] placeholder-slate-400"
                  />
                </div>
              </td>

              <td className="p-2 border-r border-slate-100 dark:border-slate-800"></td>
              <td className="p-2 border-r border-slate-100 dark:border-slate-800"></td>
              <td className="p-2 border-r border-slate-100 dark:border-slate-800"></td>
              <td className="p-2 border-r border-slate-100 dark:border-slate-800"></td>
              <td className="p-2 border-r border-slate-100 dark:border-slate-800"></td>
              <td className="p-2 border-r border-slate-100 dark:border-slate-800"></td>
              <td className="p-2"></td>
            </tr>
          </thead>

          <tbody className="divide-y divide-slate-100 dark:divide-slate-800/50">
            {currentPagedItems.length > 0 ? (
              currentPagedItems.map((item, index) => {
                const isSelected = selectedIds.includes(item.id);
                return (
                  <tr
                    key={item.id}
                    className={`hover:bg-[#f6faff]/80 dark:hover:bg-slate-800/30 transition-all duration-150 text-xs font-semibold ${
                      isSelected
                        ? 'bg-amber-50/40 dark:bg-amber-950/10'
                        : index % 2 === 0
                        ? 'bg-white dark:bg-slate-900'
                        : 'bg-slate-50/50 dark:bg-slate-950/20'
                    }`}
                  >
                    {/* Checkbox select */}
                    <td className="p-4 text-center">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={(e) => handleSelectRow(item.id, e.target.checked)}
                        className="rounded-none accent-[#005DA6] w-4 h-4 cursor-pointer"
                      />
                    </td>

                    {/* Form ID Link */}
                    <td className="p-4 font-bold text-[#005DA6] dark:text-[#FFD500] hover:underline cursor-pointer font-mono" onClick={() => onViewBadge(item)}>
                      {item.id}
                    </td>

                    {/* Schedule */}
                    <td className="p-4 text-slate-500 dark:text-slate-400 font-mono whitespace-nowrap">
                      {item.schedule}
                    </td>

                    {/* IN Timestamp */}
                    <td className="p-4 text-slate-700 dark:text-slate-300 font-mono whitespace-nowrap">
                      {item.inTime || <span className="text-slate-400 font-sans italic">Belum In</span>}
                    </td>

                    {/* OUT Timestamp */}
                    <td className="p-4 text-slate-700 dark:text-slate-300 font-mono whitespace-nowrap">
                      {item.outTime || (
                        item.status === 'IN-PROGRESS' ? (
                          <button
                            onClick={() => onCheckOut(item.id)}
                            className="px-2 py-1 bg-amber-500 hover:bg-amber-600 active:bg-amber-700 text-white font-extrabold rounded-none text-[10px] border-b border-r border-amber-300 shadow-sm transition-all flex items-center justify-center gap-1 inline-block cursor-pointer"
                          >
                            <Check size={11} />
                            Check-Out
                          </button>
                        ) : (
                          <span className="text-slate-400 font-sans italic">-</span>
                        )
                      )}
                    </td>

                    {/* Visitor Name */}
                    <td className="p-4 text-slate-800 dark:text-slate-100 font-extrabold uppercase">
                      {item.visitorName}
                    </td>

                    {/* Gate Passes */}
                    <td className="p-4">
                      <div className="flex flex-col gap-0.5">
                        <span className="font-mono text-[10px] text-amber-600 dark:text-amber-500 font-bold bg-amber-50 dark:bg-amber-950/20 px-1 rounded-none border border-amber-200/50 dark:border-amber-900/30 block w-fit truncate max-w-[120px]">
                          {item.mainGatePass || '-'}
                        </span>
                        {item.secondGatePass && (
                          <span className="font-mono text-[10px] text-sky-600 dark:text-sky-400 font-bold bg-sky-50 dark:bg-sky-950/20 px-1 rounded-none border border-sky-200/50 dark:border-sky-900/30 block w-fit truncate max-w-[120px] mt-0.5">
                            {item.secondGatePass}
                          </span>
                        )}
                      </div>
                    </td>

                    {/* Company */}
                    <td className="p-4 text-slate-600 dark:text-slate-300 font-extrabold uppercase truncate max-w-[150px]" title={item.company}>
                      {item.company}
                    </td>

                    {/* Purpose */}
                    <td className="p-4 text-slate-500 dark:text-slate-400 capitalize truncate max-w-[120px]" title={item.purpose}>
                      {item.purpose}
                    </td>

                    {/* Visited employee/department */}
                    <td className="p-4 text-slate-800 dark:text-slate-200 font-bold uppercase truncate max-w-[130px]" title={item.visited}>
                      {item.visited}
                    </td>

                    {/* Status badge */}
                    <td className="p-4 text-center">
                      {getStatusBadge(item.status)}
                    </td>

                    {/* Row action shortcuts */}
                    <td className="p-4 text-center">
                      <div className="flex items-center justify-center gap-1">
                        
                        {/* View Badge */}
                        <button
                          onClick={() => onViewBadge(item)}
                          title="Cetak Pass Masuk Tamu"
                          className="p-1.5 hover:bg-blue-50 dark:hover:bg-blue-950/40 text-[#005DA6] dark:text-[#FFD500] rounded-none hover:border border-[#005DA6] dark:border-[#FFD500] transition-all cursor-pointer"
                        >
                          <Printer size={15} />
                        </button>

                        {/* Edit details */}
                        <button
                          onClick={() => onEdit(item)}
                          title="Ubah Rincian"
                          className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400 rounded-none transition-all cursor-pointer"
                        >
                          <SlidersHorizontal size={14} />
                        </button>

                        {/* Delete record */}
                        <button
                          onClick={() => onDelete(item.id)}
                          title="Hapus Data"
                          className="p-1.5 hover:bg-rose-50 dark:hover:bg-rose-950/30 text-rose-500 dark:text-[#FF3B30] rounded-none transition-all cursor-pointer"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={12} className="p-12 text-center bg-white dark:bg-slate-900">
                  <div className="flex flex-col items-center justify-center gap-2 max-w-sm mx-auto">
                    <AlertTriangle className="text-amber-500" size={36} />
                    <p className="font-extrabold text-sm text-slate-800 dark:text-slate-200 mt-2">
                      Data Tamu Tidak Ditemukan
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 leading-normal">
                      Saringan penapis terlalu ketat, coba bersihkan filter atau tambahkan contoh data simulasi yang telah disiapkan.
                    </p>
                    <button
                      onClick={onAddSampleData}
                      className="mt-3 px-4 py-2 bg-[#005DA6] hover:bg-[#004070] text-white font-bold text-xs rounded-none border-b-2 border-r-2 border-[#FFD500] shadow-xs cursor-pointer transition-colors"
                    >
                      Muat Data Contoh SIMATA
                    </button>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination & Show Entries Footer */}
      <div className="p-5 border-t border-slate-150 dark:border-slate-800 flex flex-col sm:flex-row gap-4 items-center justify-between bg-slate-50 dark:bg-slate-950 select-none">
        
        {/* Entries select dropdown */}
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 dark:text-slate-400 font-sans">
          <span>Show</span>
          <select
            value={entriesPerPage}
            onChange={(e) => {
              setEntriesPerPage(parseInt(e.target.value));
              setCurrentPage(1);
            }}
            className="px-2 py-1.5 bg-white dark:bg-[#152033] border border-slate-200 dark:border-slate-800 rounded-none text-slate-700 dark:text-slate-300 font-bold focus:outline-none"
          >
            <option value={10}>10</option>
            <option value={20}>20</option>
            <option value={50}>50</option>
            <option value={100}>100</option>
          </select>
          <span>entries</span>
        </div>

        {/* Info stats */}
        <div className="text-xs font-semibold text-slate-500 dark:text-slate-400 font-sans">
          Showing {totalEntries > 0 ? indexOfFirstItem + 1 : 0} to {Math.min(indexOfLastItem, totalEntries)} of {totalEntries} entries
          {filteredItems.length !== visitors.length && ` (filtered from ${visitors.length} total entries)`}
        </div>

        {/* Buttons Pagination */}
        <div className="flex items-center gap-1 font-semibold text-xs">
          <button
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
            className={`px-3 py-1.5 rounded-none border text-xs font-bold transition-all ${
              currentPage === 1
                ? 'bg-slate-100 dark:bg-slate-800/40 text-slate-400 dark:text-slate-600 border-slate-150 dark:border-slate-800/80 cursor-not-allowed'
                : 'bg-white dark:bg-[#152033] hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 cursor-pointer shadow-2xs'
            }`}
          >
            Previous
          </button>

          {Array.from({ length: totalPages }, (_, i) => i + 1)
            .filter((p) => {
              // Only display around the current page
              return p === 1 || p === totalPages || Math.abs(currentPage - p) <= 1;
            })
            .map((p, index, arr) => {
              // Add dots representation
              const showDotsBefore = index > 0 && p - arr[index - 1] > 1;
              return (
                <React.Fragment key={p}>
                  {showDotsBefore && (
                    <span className="px-2 text-slate-400 select-none font-bold">...</span>
                  )}
                  <button
                    onClick={() => handlePageChange(p)}
                    className={`min-w-[32px] h-8 rounded-none text-xs font-black transition-all ${
                      currentPage === p
                        ? 'bg-[#005DA6] text-[#FFD500] border border-[#005DA6]'
                        : 'bg-white dark:bg-[#152033] hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    {p}
                  </button>
                </React.Fragment>
              );
            })}

          <button
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
            className={`px-3 py-1.5 rounded-none border text-xs font-bold transition-all ${
              currentPage === totalPages
                ? 'bg-slate-100 dark:bg-slate-800/40 text-slate-400 dark:text-slate-600 border-slate-155 dark:border-slate-800/80 cursor-not-allowed'
                : 'bg-white dark:bg-[#152033] hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 cursor-pointer shadow-2xs'
            }`}
          >
            Next
          </button>
        </div>

      </div>

    </div>
  );
}
