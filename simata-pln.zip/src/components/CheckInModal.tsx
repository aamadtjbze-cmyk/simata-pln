/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { X, Save, User, Briefcase, FileText, Lock, Users2, Calendar, Phone, ShieldCheck } from 'lucide-react';
import { Visitor, VisitorStatus } from '../types';
import { COMMON_PURPOSES, PLN_DIVISIONS } from '../data/mockData';

interface CheckInModalProps {
  visitorToEdit?: Visitor | null;
  onSave: (visitor: Visitor) => void;
  onClose: () => void;
  visitorsCount: number;
  lastFormId: string;
}

export default function CheckInModal({
  visitorToEdit,
  onSave,
  onClose,
  visitorsCount,
  lastFormId,
}: CheckInModalProps) {
  const [visitorName, setVisitorName] = useState('');
  const [company, setCompany] = useState('');
  const [purpose, setPurpose] = useState('');
  const [visited, setVisited] = useState('');
  const [mainGatePass, setMainGatePass] = useState('');
  const [secondGatePass, setSecondGatePass] = useState('');
  const [phone, setPhone] = useState('');
  const [identifyNo, setIdentifyNo] = useState('');
  const [gender, setGender] = useState<'Laki-laki' | 'Perempuan'>('Laki-laki');
  const [notes, setNotes] = useState('');
  const [schedule, setSchedule] = useState('');
  const [status, setStatus] = useState<VisitorStatus>('IN-PROGRESS');

  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    if (visitorToEdit) {
      setVisitorName(visitorToEdit.visitorName);
      setCompany(visitorToEdit.company);
      setPurpose(visitorToEdit.purpose);
      setVisited(visitorToEdit.visited);
      setMainGatePass(visitorToEdit.mainGatePass);
      setSecondGatePass(visitorToEdit.secondGatePass);
      setPhone(visitorToEdit.phone || '');
      setIdentifyNo(visitorToEdit.identifyNo || '');
      setGender(visitorToEdit.gender || 'Laki-laki');
      setNotes(visitorToEdit.notes || '');
      setSchedule(visitorToEdit.schedule);
      setStatus(visitorToEdit.status);
    } else {
      // Default dates to current time
      const today = new Date();
      const pad = (num: number) => String(num).padStart(2, '0');
      const day = today.getDate();
      const monthNames = ["June", "January", "February", "March", "April", "May", "July", "August", "September", "October", "November", "December"];
      const monthName = monthNames[today.getMonth()];
      const year = today.getFullYear();
      const hours = pad(today.getHours());
      const mins = pad(today.getMinutes());
      
      setSchedule(`${day} ${monthName} ${year} - ${hours}.${mins}`);
      setStatus('IN-PROGRESS');
    }
  }, [visitorToEdit]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: { [key: string]: string } = {};

    if (!visitorName.trim()) newErrors.visitorName = 'Nama tamu harus diisi';
    if (!company.trim()) newErrors.company = 'Nama instansi/perusahaan harus diisi';
    if (!purpose.trim()) newErrors.purpose = 'Tujuan kunjungan harus dipilih/diisi';
    if (!visited.trim()) newErrors.visited = 'Divisi/Pegawai yang dikunjungi harus dipilih/diisi';

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    // Auto generate ID if not editing
    let formId = visitorToEdit?.id;
    if (!formId) {
      const match = lastFormId.match(/(\d+)$/);
      const nextNum = match ? parseInt(match[1]) + 1 : 5009;
      formId = `TJB-VST-${String(nextNum).padStart(6, '0')}`;
    }

    const todayDate = new Date();
    const padDigit = (n: number) => String(n).padStart(2, '0');
    const day = todayDate.getDate();
    const monthNames = ["June", "January", "February", "March", "April", "May", "July", "August", "September", "October", "November", "December"];
    const month = monthNames[todayDate.getMonth()];
    const year = todayDate.getFullYear();
    const hours = padDigit(todayDate.getHours());
    const mins = padDigit(todayDate.getMinutes());
    const formattedInTime = `${day} ${month} ${year} - ${hours}.${padDigit(todayDate.getMinutes())}`;

    const visitorData: Visitor = {
      id: formId,
      schedule,
      inTime: visitorToEdit ? visitorToEdit.inTime : (status === 'IN-PROGRESS' ? formattedInTime : null),
      outTime: visitorToEdit ? visitorToEdit.outTime : null,
      visitorName: visitorName.toUpperCase(),
      mainGatePass,
      secondGatePass,
      company: company.toUpperCase(),
      purpose,
      visited: visited.toUpperCase(),
      status,
      phone,
      identifyNo,
      gender,
      notes,
    };

    onSave(visitorData);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto animate-fade-in">
      <div className="bg-white dark:bg-[#111c30] rounded-none max-w-2xl w-full shadow-2xl overflow-hidden my-8 border-2 border-[#005DA6]">
        
        {/* Header banner */}
        <div className="bg-[#005DA6] border-b-2 border-[#FFD500] px-6 py-5 text-white flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-bold tracking-widest text-[#FFD500] font-sans">
              {visitorToEdit ? 'Ubah Informasi' : 'Registrasi Masuk'}
            </span>
            <h3 className="text-xl font-black tracking-tight mt-0.5 uppercase font-display">
              {visitorToEdit ? 'Ubah Data Kunjungan' : 'Registrasi Tamu Baru (Check-In)'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 bg-white/10 hover:bg-white/20 active:bg-white/30 rounded-none text-white transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            
            {/* Identity Group */}
            <div className="space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5 pb-1 border-b border-slate-100 dark:border-slate-800">
                <User size={13} />
                Identitas Tamu
              </h4>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Nama Lengkap Tamu <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={visitorName}
                  onChange={(e) => {
                    setVisitorName(e.target.value);
                    if (errors.visitorName) setErrors({ ...errors, visitorName: '' });
                  }}
                  placeholder="Contoh: DIKY TRI JUNIANTO"
                  className={`w-full px-4 py-2.5 bg-slate-50 dark:bg-[#152033] border ${errors.visitorName ? 'border-rose-500' : 'border-slate-200 dark:border-slate-800'} rounded-none text-slate-800 dark:text-slate-200 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-[#005DA6]`}
                />
                {errors.visitorName && <span className="text-rose-500 text-[10px] font-semibold mt-1 block">{errors.visitorName}</span>}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Nomor KTP / SIM / ID Card
                </label>
                <input
                  type="text"
                  value={identifyNo}
                  onChange={(e) => setIdentifyNo(e.target.value)}
                  placeholder="Masukkan 16 digit NIK atau KTP"
                  className="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#152033] border border-slate-200 dark:border-slate-800 rounded-none text-slate-800 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#005DA6]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Jenis Kelamin
                  </label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value as any)}
                    className="w-full px-3 py-2.5 bg-slate-50 dark:bg-[#152033] border border-slate-200 dark:border-slate-800 rounded-none text-slate-800 dark:text-slate-200 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-[#005DA6]"
                  >
                    <option value="Laki-laki">Laki-laki</option>
                    <option value="Perempuan">Perempuan</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Nomor Telepon/WA
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="08xxxxxxxxxx"
                    className="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#152033] border border-slate-200 dark:border-slate-800 rounded-none text-slate-800 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#005DA6]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Instansi / Perusahaan Tamu <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={company}
                  onChange={(e) => {
                    setCompany(e.target.value);
                    if (errors.company) setErrors({ ...errors, company: '' });
                  }}
                  placeholder="Contoh: PT PT SUCOFINDO / PLN BANGSRI"
                  className={`w-full px-4 py-2.5 bg-slate-50 dark:bg-[#152033] border ${errors.company ? 'border-rose-500' : 'border-slate-200 dark:border-slate-800'} rounded-none text-slate-800 dark:text-slate-200 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-[#005DA6]`}
                />
                {errors.company && <span className="text-rose-500 text-[10px] font-semibold mt-1 block">{errors.company}</span>}
              </div>

            </div>

            {/* Visit Details Group */}
            <div className="space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5 pb-1 border-b border-slate-100 dark:border-slate-800">
                <Briefcase size={13} />
                Detail Kunjungan Pelayanan
              </h4>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Tujuan Kunjungan <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <select
                    value={COMMON_PURPOSES.includes(purpose) ? purpose : 'Lainnya'}
                    onChange={(e) => {
                      const val = e.target.value;
                      if (val === 'Lainnya') {
                        setPurpose('');
                      } else {
                        setPurpose(val);
                      }
                      if (errors.purpose) setErrors({ ...errors, purpose: '' });
                    }}
                    className="w-full px-3 py-2.5 bg-slate-50 dark:bg-[#152033] border border-slate-200 dark:border-slate-800 rounded-none text-slate-800 dark:text-slate-200 text-sm font-semibold focus:outline-none mb-2 focus:ring-2 focus:ring-[#005DA6]"
                  >
                    <option value="">-- Pilih Tujuan --</option>
                    {COMMON_PURPOSES.map((p) => (
                      <option key={p} value={p}>{p}</option>
                    ))}
                  </select>
                  
                  {(!COMMON_PURPOSES.includes(purpose) || purpose === '') && (
                    <input
                      type="text"
                      value={purpose}
                      onChange={(e) => {
                        setPurpose(e.target.value);
                        if (errors.purpose) setErrors({ ...errors, purpose: '' });
                      }}
                      placeholder="Tulis tujuan khusus..."
                      className="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#152033] border border-slate-200 dark:border-slate-800 rounded-none text-slate-800 dark:text-slate-200 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-[#005DA6]"
                    />
                  )}
                </div>
                {errors.purpose && <span className="text-rose-500 text-[10px] font-semibold mt-1 block">{errors.purpose}</span>}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Divisi / Pegawai yang Dikunjungi <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <select
                    value={PLN_DIVISIONS.includes(visited) ? visited : 'Lainnya'}
                    onChange={(e) => {
                      const val = e.target.value;
                      if (val === 'Lainnya') {
                        setVisited('');
                      } else {
                        setVisited(val);
                      }
                      if (errors.visited) setErrors({ ...errors, visited: '' });
                    }}
                    className="w-full px-3 py-2.5 bg-slate-50 dark:bg-[#152033] border border-slate-200 dark:border-slate-800 rounded-none text-slate-800 dark:text-slate-200 text-sm font-semibold focus:outline-none mb-2 focus:ring-2 focus:ring-[#005DA6]"
                  >
                    <option value="">-- Pilih Pegawai/Divisi --</option>
                    {PLN_DIVISIONS.map((d) => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>

                  {(!PLN_DIVISIONS.includes(visited) || visited === '') && (
                    <input
                      type="text"
                      value={visited}
                      onChange={(e) => {
                        setVisited(e.target.value);
                        if (errors.visited) setErrors({ ...errors, visited: '' });
                      }}
                      placeholder="Nama Pegawai / Divisi khusus..."
                      className="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#152033] border border-slate-200 dark:border-slate-800 rounded-none text-slate-800 dark:text-slate-200 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-[#005DA6]"
                    />
                  )}
                </div>
                {errors.visited && <span className="text-rose-500 text-[10px] font-semibold mt-1 block">{errors.visited}</span>}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Main Gate Pass (Kartu Utama)
                  </label>
                  <input
                    type="text"
                    value={mainGatePass}
                    onChange={(e) => setMainGatePass(e.target.value)}
                    placeholder="Contoh: Vgp 021"
                    className="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#152033] border border-slate-200 dark:border-slate-800 rounded-none text-slate-800 dark:text-slate-200 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-[#005DA6]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    2nd Gate Pass (Kartu Tambahan)
                  </label>
                  <input
                    type="text"
                    value={secondGatePass}
                    onChange={(e) => setSecondGatePass(e.target.value)}
                    placeholder="Contoh: 014 k"
                    className="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#152033] border border-slate-200 dark:border-slate-800 rounded-none text-slate-800 dark:text-slate-200 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-[#005DA6]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Jadwal / Waktu Kedatangan
                  </label>
                  <input
                    type="text"
                    value={schedule}
                    onChange={(e) => setSchedule(e.target.value)}
                    placeholder="Tanggal - Jam"
                    className="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#152033] border border-slate-200 dark:border-slate-800 rounded-none text-slate-800 dark:text-slate-200 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-[#005DA6]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Status Kunjungan Awal
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as VisitorStatus)}
                    className="w-full px-3 py-2.5 bg-slate-50 dark:bg-[#152033] border border-slate-200 dark:border-slate-800 rounded-none text-slate-800 dark:text-slate-200 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-[#005DA6]"
                  >
                    <option value="IN-PROGRESS">IN-PROGRESS (Sedang Berkunjung)</option>
                    <option value="SCHEDULED">SCHEDULED (Rencana Pertemuan)</option>
                    <option value="PENDING">PENDING (Menunggu Persetujuan)</option>
                    <option value="DONE">DONE (Selesai Berkunjung/Out)</option>
                  </select>
                </div>
              </div>

            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Catatan Keamanan / Barang Bawaan
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Contoh: Membawa laptop dinas ASUS, memarkir kendaraan Mobil AD 1930 PL di Gate 1..."
              rows={3}
              className="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#152033] border border-slate-200 dark:border-slate-800 rounded-none text-slate-800 dark:text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#005DA6]"
            />
          </div>

          {/* Footer controls */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
            <span className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider flex items-center gap-1">
              <ShieldCheck size={14} className="text-emerald-500" />
              Verifikasi Pos Keamanan Utama PLN
            </span>
            <div className="flex gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-5 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-355 rounded-none text-sm font-bold transition-colors cursor-pointer border border-slate-200 dark:border-slate-700"
              >
                Batal
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 bg-[#005DA6] hover:bg-[#004070] active:bg-[#003056] text-white rounded-none border-b-2 border-r-2 border-[#FFD500] text-sm font-bold flex items-center gap-2 shadow-sm transition-colors cursor-pointer"
              >
                <Save size={16} />
                Simpan & Check-In
              </button>
            </div>
          </div>
        </form>

      </div>
    </div>
  );
}
