/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  PlusCircle,
  ShieldAlert,
  Moon,
  Sun,
  RotateCcw,
  BookOpen,
  Info,
  CheckCircle2,
  Trash2,
  Lock,
  UserCheck2,
  HelpCircle,
  FileSpreadsheet,
  Bell,
  BarChart2,
  Palette,
  X
} from 'lucide-react';
import PLNLogo from './components/PLNLogo';
import StatsDashboard from './components/StatsDashboard';
import VisitorTable from './components/VisitorTable';
import CheckInModal from './components/CheckInModal';
import BadgeModal from './components/BadgeModal';
import ReportModule from './components/ReportModule';
import NotificationCenter from './components/NotificationCenter';
import ThemeStudioModal from './components/ThemeStudioModal';
import { createNotification } from './lib/notificationHelper';
import { Visitor, VisitorStatus, SystemNotification } from './types';
import { INITIAL_VISITORS } from './data/mockData';

export default function App() {
  const [visitors, setVisitors] = useState<Visitor[]>([]);
  const [notifications, setNotifications] = useState<SystemNotification[]>([]);
  const [currentTab, setCurrentTab] = useState<'buku-tamu' | 'notifikasi' | 'laporan'>('buku-tamu');
  const [isCheckInOpen, setIsCheckInOpen] = useState(false);
  const [isThemeStudioOpen, setIsThemeStudioOpen] = useState(false);
  const [visitorToEdit, setVisitorToEdit] = useState<Visitor | null>(null);
  const [visitorForBadge, setVisitorForBadge] = useState<Visitor | null>(null);
  const [isSopOpen, setIsSopOpen] = useState(false);
  const [isBannerVisible, setIsBannerVisible] = useState(true);
  
  // Theme state
  const [darkMode, setDarkMode] = useState(false);
  const [currentTheme, setCurrentTheme] = useState<'klasik' | 'ebt' | 'cyber' | 'geothermal'>('klasik');
  const [bgStyle, setBgStyle] = useState<string>('slate-50');
  
  // UI Toast alert state
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' | 'danger' } | null>(null);

  // Derive the last/maximum Form ID to prevent duplicate key assignment
  const lastFormId = visitors.length > 0 
    ? [...visitors].sort((a, b) => b.id.localeCompare(a.id))[0].id 
    : 'TJB-VST-005008';

  // Initialize data on component mount
  useEffect(() => {
    const saved = localStorage.getItem('simata_visitors');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          // Keep only the first occurrence of each unique ID
          const uniqueIds = new Set<string>();
          const deduplicated = parsed.filter((v) => {
            if (v && v.id) {
              if (uniqueIds.has(v.id)) return false;
              uniqueIds.add(v.id);
              return true;
            }
            return false;
          });
          setVisitors(deduplicated);
          if (deduplicated.length !== parsed.length) {
            localStorage.setItem('simata_visitors', JSON.stringify(deduplicated));
          }
        } else {
          setVisitors(INITIAL_VISITORS);
        }
      } catch (e) {
        setVisitors(INITIAL_VISITORS);
      }
    } else {
      setVisitors(INITIAL_VISITORS);
      localStorage.setItem('simata_visitors', JSON.stringify(INITIAL_VISITORS));
    }

    // Load notifications from local storage
    const savedNotifs = localStorage.getItem('simata_notifications');
    if (savedNotifs) {
      try {
        setNotifications(JSON.parse(savedNotifs));
      } catch (e) {
        setNotifications([]);
      }
    }

    // Load theme setting from local storage
    const savedTheme = localStorage.getItem('simata_theme') as 'klasik' | 'ebt' | 'cyber' | 'geothermal' | null;
    if (savedTheme) {
      try {
        setCurrentTheme(savedTheme);
      } catch (e) {
        setCurrentTheme('klasik');
      }
    }

    // Force default to Light Theme once to align with user preference, else load from localStorage
    const hasResetToLight = localStorage.getItem('simata_reset_to_light_v3');
    let initialDarkModeValue = false;
    if (!hasResetToLight) {
      setDarkMode(false);
      localStorage.setItem('simata_dark_mode', 'false');
      localStorage.setItem('simata_reset_to_light_v3', 'true');
    } else {
      const savedDarkMode = localStorage.getItem('simata_dark_mode');
      if (savedDarkMode) {
        try {
          const parsed = JSON.parse(savedDarkMode);
          setDarkMode(parsed);
          initialDarkModeValue = parsed;
        } catch (e) {
          setDarkMode(false);
        }
      }
    }

    const savedBgStyle = localStorage.getItem('simata_bg_style');
    if (savedBgStyle) {
      setBgStyle(savedBgStyle);
    } else {
      setBgStyle(initialDarkModeValue ? 'midnight-deep' : 'slate-50');
    }
  }, []);

  // Save changes helper
  const saveAndSync = (newVisitors: Visitor[]) => {
    setVisitors(newVisitors);
    localStorage.setItem('simata_visitors', JSON.stringify(newVisitors));
  };

  // Toast feedback notice trigger
  const triggerToast = (message: string, type: 'success' | 'info' | 'danger' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  // Theme toggle helper
  const toggleTheme = () => {
    const nextVal = !darkMode;
    setDarkMode(nextVal);
    localStorage.setItem('simata_dark_mode', JSON.stringify(nextVal));
    
    const nextBgStyle = nextVal ? 'midnight-deep' : 'slate-50';
    setBgStyle(nextBgStyle);
    localStorage.setItem('simata_bg_style', nextBgStyle);
    
    triggerToast(nextVal ? "Mode Gelap korporat diaktifkan" : "Mode Terang korporat diaktifkan", "info");
  };

  // Save notification list helper
  const saveAndSyncNotifications = (newNotifs: SystemNotification[]) => {
    setNotifications(newNotifs);
    localStorage.setItem('simata_notifications', JSON.stringify(newNotifs));
  };

  // Add / Edit Visitor callback
  const handleSaveVisitor = (savedVisitor: Visitor) => {
    const exists = visitors.some((v) => v.id === savedVisitor.id);
    let updated: Visitor[];
    let newNotifs = [...notifications];
    
    if (exists) {
      const original = visitors.find((v) => v.id === savedVisitor.id);
      const statusChanged = original && original.status !== savedVisitor.status;
      
      // Update existing record
      updated = visitors.map((v) => (v.id === savedVisitor.id ? savedVisitor : v));
      triggerToast(`Data tamu ${savedVisitor.visitorName} berhasil diubah.`, 'info');
      
      if (statusChanged) {
        const notif = createNotification(savedVisitor, original.status);
        newNotifs = [notif, ...newNotifs];
        saveAndSyncNotifications(newNotifs);
      }
    } else {
      // Insert new record at the top of the log
      updated = [savedVisitor, ...visitors];
      triggerToast(`Registrasi ${savedVisitor.visitorName} berhasil! Kartu masuk diterbitkan.`, 'success');
      // Auto open badge after registration
      setVisitorForBadge(savedVisitor);

      const notif = createNotification(savedVisitor);
      newNotifs = [notif, ...newNotifs];
      saveAndSyncNotifications(newNotifs);
    }
    
    saveAndSync(updated);
    setIsCheckInOpen(false);
    setVisitorToEdit(null);
  };

  // Check-Out Single Visitor
  const handleCheckOut = (visitorId: string) => {
    const today = new Date();
    const pad = (num: number) => String(num).padStart(2, '0');
    const day = today.getDate();
    const monthNames = ["June", "January", "February", "March", "April", "May", "July", "August", "September", "October", "November", "December"];
    const monthName = monthNames[today.getMonth()];
    const year = today.getFullYear();
    const hours = pad(today.getHours());
    const mins = pad(today.getMinutes());
    const formattedOutTime = `${day} ${monthName} ${year} - ${hours}.${mins}`;

    const original = visitors.find((v) => v.id === visitorId);
    const updated = visitors.map((v) => {
      if (v.id === visitorId) {
        return {
          ...v,
          status: 'DONE' as VisitorStatus,
          outTime: formattedOutTime,
        };
      }
      return v;
    });

    if (original) {
      triggerToast(`Tamu ${original.visitorName} telah berhasil Check-Out.`, 'success');
      
      const updatedVisitor: Visitor = {
        ...original,
        status: 'DONE',
        outTime: formattedOutTime
      };
      
      const notif = createNotification(updatedVisitor, original.status);
      const newNotifs = [notif, ...notifications];
      saveAndSyncNotifications(newNotifs);
    }
    saveAndSync(updated);
  };

  // Check-Out Batch selected visitors
  const handleCheckOutBatch = (visitorIds: string[]) => {
    const today = new Date();
    const pad = (num: number) => String(num).padStart(2, '0');
    const day = today.getDate();
    const monthNames = ["June", "January", "February", "March", "April", "May", "July", "August", "September", "October", "November", "December"];
    const monthName = monthNames[today.getMonth()];
    const year = today.getFullYear();
    const hours = pad(today.getHours());
    const mins = pad(today.getMinutes());
    const formattedOutTime = `${day} ${monthName} ${year} - ${hours}.${mins}`;

    let newNotifs = [...notifications];
    const updated = visitors.map((v) => {
      if (visitorIds.includes(v.id) && v.status === 'IN-PROGRESS') {
        const updatedVisitor: Visitor = {
          ...v,
          status: 'DONE',
          outTime: formattedOutTime,
        };
        const notif = createNotification(updatedVisitor, 'IN-PROGRESS');
        newNotifs = [notif, ...newNotifs];
        return updatedVisitor;
      }
      return v;
    });

    triggerToast(`Berhasil Check-Out ${visitorIds.length} tamu sekaligus.`, 'success');
    saveAndSyncNotifications(newNotifs);
    saveAndSync(updated);
  };

  // Delete single Visitor log
  const handleDeleteVisitor = (visitorId: string) => {
    const target = visitors.find((v) => v.id === visitorId);
    const confirmMsg = target 
      ? `Apakah Anda yakin ingin menghapus catatan kunjungan tamu: "${target.visitorName}" (${target.company})?`
      : 'Apakah Anda yakin ingin menghapus catatan tamu ini?';

    if (confirm(confirmMsg)) {
      const updated = visitors.filter((v) => v.id !== visitorId);
      triggerToast(`Catatan tamu ${target?.visitorName || ''} berhasil dihapus.`, 'danger');
      saveAndSync(updated);
    }
  };

  // Reset database back to rich defaults
  const handleResetDatabase = () => {
    if (confirm('Apakah Anda ingin mereset seluruh data kembali ke setelan bawaan SIMATA PLN? Semua penambahan tamu baru akan terhapus.')) {
      saveAndSync(INITIAL_VISITORS);
      setNotifications([]);
      localStorage.removeItem('simata_notifications');
      triggerToast('Sistem log tamu & notifikasi berhasil di-reset ke data bawaan.', 'info');
    }
  };

  // Generate random visitor entry for quickly testing simulation flow
  const handleAddSampleVisitor = () => {
    const sampleNames = ['BUDI SANTOSO', 'ANI WIJAYA', 'CECEP PRIADI', 'DEWI LESTARI', 'EKO PRASETYO', 'HERMAN GUNA'];
    const sampleCompanies = ['PT ADHI KARYA', 'PT INDOSAT TBK', 'KEMENTERIAN BUMN', 'PT REKAYASA INDUSTRI', 'CV SINAR UTAMA'];
    const samplePurposes = ['Konsultasi Gardu Distribusi', 'Pengiriman suku cadang tiang', 'Presentasi tender kabel PLN', 'Rapat koordinasi AMDAL'];
    const sampleVisited = ['IKRAM', 'PLN KKU', 'PLN LAKSDA', 'KEUANGAN PLN', 'DIVISI IT PLN'];

    const randomName = sampleNames[Math.floor(Math.random() * sampleNames.length)];
    const randomComp = sampleCompanies[Math.floor(Math.random() * sampleCompanies.length)];
    const randomPurp = samplePurposes[Math.floor(Math.random() * samplePurposes.length)];
    const randomVis = sampleVisited[Math.floor(Math.random() * sampleVisited.length)];

    const match = lastFormId.match(/(\d+)$/);
    const nextNum = match ? parseInt(match[1]) + 1 : 5009;
    const newId = `TJB-VST-${String(nextNum).padStart(6, '0')}`;

    const today = new Date();
    const pad = (num: number) => String(num).padStart(2, '0');
    const formattedInTime = `${today.getDate()} June ${today.getFullYear()} - ${pad(today.getHours())}.${pad(today.getMinutes())}`;

    const sampleGuest: Visitor = {
      id: newId,
      schedule: formattedInTime,
      inTime: formattedInTime,
      outTime: null,
      visitorName: randomName,
      mainGatePass: `Vgp ${pad(Math.floor(Math.random() * 50) + 1)}`,
      secondGatePass: Math.random() > 0.5 ? `${pad(Math.floor(Math.random() * 20))} k` : '',
      company: randomComp,
      purpose: randomPurp,
      visited: randomVis,
      status: 'IN-PROGRESS',
      phone: '0812' + Math.floor(10000000 + Math.random() * 90000000),
      identifyNo: '3273' + Math.floor(100000000000 + Math.random() * 900000000000),
      gender: Math.random() > 0.5 ? 'Laki-laki' : 'Perempuan',
      notes: 'Ditambahkan via generator cepat SIMATA'
    };

    saveAndSync([sampleGuest, ...visitors]);
    triggerToast(`Ditambahkan tamu simulasi: ${randomName}`, 'success');

    // Automatically trigger check-in notification for sample visitor!
    const notif = createNotification(sampleGuest);
    const newNotifs = [notif, ...notifications];
    saveAndSyncNotifications(newNotifs);
  };

  const handleClearAllNotifications = () => {
    setNotifications([]);
    localStorage.removeItem('simata_notifications');
    triggerToast('Seluruh log notifikasi berhasil dihapus.', 'danger');
  };

  const handleResendNotification = (notifId: string) => {
    const target = notifications.find(n => n.id === notifId);
    if (target) {
      const now = new Date();
      const pad = (num: number) => String(num).padStart(2, '0');
      const timeStr = `${now.getHours()}.${pad(now.getMinutes())}`;
      
      triggerToast(`Notifikasi ${target.id} berhasil dikirim ulang via ${target.channel} pada ${timeStr}.`, 'success');
      
      const updatedNotifs = notifications.map(n => {
        if (n.id === notifId) {
          return {
            ...n,
            timestamp: `${now.getDate()} June ${now.getFullYear()} - ${timeStr} (Resent)`
          };
        }
        return n;
      });
      saveAndSyncNotifications(updatedNotifs);
    }
  };

  const getToastStyle = (type: string) => {
    switch (type) {
      case 'success':
        return 'bg-emerald-600 text-white';
      case 'danger':
        return 'bg-rose-600 text-white';
      case 'info':
      default:
        return 'bg-[#0067B1] text-white';
    }
  };

  const getBackgroundClass = () => {
    if (darkMode) {
      if (bgStyle === 'midnight-deep') return 'bg-[#0a1120]';
      if (bgStyle === 'carbon-obsidian') return 'bg-slate-950';
      if (bgStyle === 'circuit-black') return 'bg-[#0b0c15]';
      if (bgStyle === 'magma-dark') return 'bg-[#1a0a0d]';
      return 'bg-[#0e1726]';
    } else {
      if (bgStyle === 'white') return 'bg-white';
      if (bgStyle === 'slate-50') return 'bg-slate-50';
      if (bgStyle === 'cream') return 'bg-[#FAF6EE]';
      if (bgStyle === 'sky-blue') return 'bg-[#EDF5FA]';
      return 'bg-slate-50';
    }
  };

  return (
    <div className={`${darkMode ? 'dark text-slate-100' : 'text-[#1a2e40]'} ${getBackgroundClass()} min-h-screen flex flex-col theme-${currentTheme} transition-colors duration-250 font-sans`}>
      
      {/* Dynamic Style Overrides for Themes */}
      <style>{`
        /* PLN EBT Theme: Emerald Green & Golden Honey */
        .theme-ebt .bg-\\[\\#005DA6\\] { background-color: #0d9488 !important; }
        .theme-ebt .text-\\[\\#005DA6\\] { color: #0d9488 !important; }
        .theme-ebt .border-\\[\\#005DA6\\] { border-color: #0d9488 !important; }
        .theme-ebt .focus\\:ring-\\[\\#005DA6\\]:focus { --tw-ring-color: #0d9488 !important; }
        .theme-ebt .hover\\:bg-\\[\\#004070\\]:hover { background-color: #0f766e !important; }
        .theme-ebt .hover\\:text-\\[\\#005DA6\\]:hover { color: #0d9488 !important; }
        .theme-ebt .border-\\[\\#FFD500\\] { border-color: #f59e0b !important; }
        .theme-ebt .text-\\[\\#FFD500\\] { color: #f59e0b !important; }
        .theme-ebt .bg-sky-50\\/70 { background-color: rgba(240, 253, 250, 0.70) !important; }
        .theme-ebt .dark\\:bg-\\[\\#152033\\]\\/60 { background-color: rgba(13, 148, 136, 0.15) !important; }
        .theme-ebt .border-l-\\[\\#005DA6\\] { border-left-color: #0d9488 !important; }
        .theme-ebt .bg-\\[\\#005DA6\\]\\/10 { background-color: rgba(13, 148, 136, 0.1) !important; }
        .theme-ebt .stroke-\\[\\#005DA6\\] { stroke: #0d9488 !important; }
        .theme-ebt .fill-\\[\\#FFD500\\] { fill: #f59e0b !important; }
        .theme-ebt .border-b-\\[\\#005DA6\\] { border-bottom-color: #0d9488 !important; }
        .theme-ebt .border-t-\\[\\#005DA6\\] { border-top-color: #0d9488 !important; }
        .theme-ebt .border-r-\\[\\#005DA6\\] { border-right-color: #0d9488 !important; }
        .theme-ebt .border-b-4 { border-bottom-color: #0d9488 !important; }
        .theme-ebt .border-t-2 { border-color: #0d9488 !important; }
        .theme-ebt .text-\\[\\#005DA6\\] { color: #0d9488 !important; }
        .theme-ebt .text-\\[\\#FFD500\\] { color: #f59e0b !important; }
        .theme-ebt text { fill: #0d9488 !important; }

        /* PLN Cyber Volt Theme: Neon Indigo & Pure Cyan */
        .theme-cyber .bg-\\[\\#005DA6\\] { background-color: #6366f1 !important; }
        .theme-cyber .text-\\[\\#005DA6\\] { color: #6366f1 !important; }
        .theme-cyber .border-\\[\\#005DA6\\] { border-color: #6366f1 !important; }
        .theme-cyber .focus\\:ring-\\[\\#005DA6\\]:focus { --tw-ring-color: #6366f1 !important; }
        .theme-cyber .hover\\:bg-\\[\\#004070\\]:hover { background-color: #4f46e5 !important; }
        .theme-cyber .hover\\:text-\\[\\#005DA6\\]:hover { color: #6366f1 !important; }
        .theme-cyber .border-\\[\\#FFD500\\] { border-color: #06b6d4 !important; }
        .theme-cyber .text-\\[\\#FFD500\\] { color: #06b6d4 !important; }
        .theme-cyber .bg-sky-50\\/70 { background-color: rgba(238, 242, 255, 0.70) !important; }
        .theme-cyber .dark\\:bg-\\[\\#152033\\]\\/60 { background-color: rgba(99, 102, 241, 0.15) !important; }
        .theme-cyber .border-l-\\[\\#005DA6\\] { border-left-color: #6366f1 !important; }
        .theme-cyber .bg-\\[\\#005DA6\\]\\/10 { background-color: rgba(99, 102, 241, 0.1) !important; }
        .theme-cyber .stroke-\\[\\#005DA6\\] { stroke: #6366f1 !important; }
        .theme-cyber .fill-\\[\\#FFD500\\] { fill: #06b6d4 !important; }
        .theme-cyber .border-b-\\[\\#005DA6\\] { border-bottom-color: #6366f1 !important; }
        .theme-cyber .border-t-\\[\\#005DA6\\] { border-top-color: #6366f1 !important; }
        .theme-cyber .border-r-\\[\\#005DA6\\] { border-right-color: #6366f1 !important; }
        .theme-cyber .border-b-4 { border-bottom-color: #6366f1 !important; }
        .theme-cyber .border-t-2 { border-color: #6366f1 !important; }
        .theme-cyber .text-\\[\\#005DA6\\] { color: #6366f1 !important; }
        .theme-cyber .text-\\[\\#FFD500\\] { color: #06b6d4 !important; }
        .theme-cyber text { fill: #6366f1 !important; }

        /* PLN Geothermal Theme: Crimson Volt & Amber Core */
        .theme-geothermal .bg-\\[\\#005DA6\\] { background-color: #e11d48 !important; }
        .theme-geothermal .text-\\[\\#005DA6\\] { color: #e11d48 !important; }
        .theme-geothermal .border-\\[\\#005DA6\\] { border-color: #e11d48 !important; }
        .theme-geothermal .focus\\:ring-\\[\\#005DA6\\]:focus { --tw-ring-color: #e11d48 !important; }
        .theme-geothermal .hover\\:bg-\\[\\#004070\\]:hover { background-color: #be123c !important; }
        .theme-geothermal .hover\\:text-\\[\\#005DA6\\]:hover { color: #e11d48 !important; }
        .theme-geothermal .border-\\[\\#FFD500\\] { border-color: #f59e0b !important; }
        .theme-geothermal .text-\\[\\#FFD500\\] { color: #f59e0b !important; }
        .theme-geothermal .bg-sky-50\\/70 { background-color: rgba(254, 242, 242, 0.70) !important; }
        .theme-geothermal .dark\\:bg-\\[\\#152033\\]\\/60 { background-color: rgba(225, 29, 72, 0.15) !important; }
        .theme-geothermal .border-l-\\[\\#005DA6\\] { border-left-color: #e11d48 !important; }
        .theme-geothermal .bg-\\[\\#005DA6\\]\\/10 { background-color: rgba(225, 29, 72, 0.1) !important; }
        .theme-geothermal .stroke-\\[\\#005DA6\\] { stroke: #e11d48 !important; }
        .theme-geothermal .fill-\\[\\#FFD500\\] { fill: #f59e0b !important; }
        .theme-geothermal .border-b-\\[\\#005DA6\\] { border-bottom-color: #e11d48 !important; }
        .theme-geothermal .border-t-\\[\\#005DA6\\] { border-top-color: #e11d48 !important; }
        .theme-geothermal .border-r-\\[\\#005DA6\\] { border-right-color: #e11d48 !important; }
        .theme-geothermal .border-b-4 { border-bottom-color: #e11d48 !important; }
        .theme-geothermal .border-t-2 { border-color: #e11d48 !important; }
        .theme-geothermal .text-\\[\\#005DA6\\] { color: #e11d48 !important; }
        .theme-geothermal .text-\\[\\#FFD500\\] { color: #f59e0b !important; }
        .theme-geothermal text { fill: #e11d48 !important; }
      `}</style>
      
      {/* Toast Notification HUD */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 animate-fade-in">
          <div className={`px-5 py-3 rounded-none shadow-[4px_4px_0px_rgba(0,0,0,0.15)] flex items-center gap-3.5 border-2 border-white/20 ${getToastStyle(toast.type)}`}>
            <CheckCircle2 size={16} className="text-[#FFD500]" />
            <span className="text-xs font-bold font-sans tracking-wide uppercase">{toast.message}</span>
          </div>
        </div>
      )}

      {/* Top Banner & Header Navigation */}
      <header className="sticky top-0 bg-white/95 dark:bg-[#111c30]/95 backdrop-blur-md border-b-2 border-[#005DA6] z-40 shadow-xs transition-colors flex-shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          
          {/* Logo Brand PLN */}
          <PLNLogo showText={true} size="md" />

          {/* Right Controls Area */}
          <div className="flex items-center gap-4">
            
            {/* Quick Demo Helper */}
            <div className="hidden md:flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-none border border-slate-200 dark:border-slate-700">
              <button
                onClick={handleAddSampleVisitor}
                className="px-3 py-1.5 hover:bg-white dark:hover:bg-slate-700 hover:text-sky-600 rounded-none text-[10px] font-black transition-all flex items-center gap-1 uppercase"
                title="Tambahkan 1 Tamu Berita Acara Acak"
              >
                Simulasi Tamu
              </button>
              <button
                onClick={handleResetDatabase}
                className="p-1.5 hover:bg-white dark:hover:bg-slate-700 text-slate-600 dark:text-slate-400 rounded-none"
                title="Reset Database SIMATA"
              >
                <RotateCcw size={13} />
              </button>
            </div>

            {/* Custom Theme Palette Gallery CTA */}
            <button
              onClick={() => setIsThemeStudioOpen(true)}
              className="flex items-center gap-2 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-750 border border-slate-200 dark:border-slate-750 py-2 px-3.5 rounded-none text-[10px] font-black uppercase tracking-wider text-slate-700 dark:text-slate-200 cursor-pointer transition-all shadow-xs"
              title="Sajikan Pilihan Tema & Studio Harmoni Kontras"
            >
              <Palette size={13} className="text-[#005DA6] dark:text-[#FFD500] animate-bounce" />
              <span>Pilihan Tema</span>
            </button>

            {/* Light/Dark Toggle */}
            <button
              onClick={toggleTheme}
              className="p-2.5 bg-slate-50 hover:bg-slate-150 dark:bg-slate-800 dark:hover:bg-slate-700 rounded-none text-slate-500 dark:text-slate-300 border border-slate-200 dark:border-slate-750 transition-all cursor-pointer"
              title="Ganti Tema Visual"
            >
              {darkMode ? <Sun size={15} className="text-[#FFD500]" /> : <Moon size={15} />}
            </button>

            {/* Operator Tagging Badge */}
            <div className="hidden sm:flex flex-col items-end pr-1 text-right select-none">
              <span className="text-[10px] font-black tracking-widest text-[#005DA6] dark:text-sky-350 uppercase">
                RECEPTIONIST PLN
              </span>
              <span className="text-[9px] font-bold text-emerald-500 flex items-center gap-1 mt-0.5">
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-none animate-pulse"></span>
                POS KAMPUS DJAWA TENGGAH
              </span>
            </div>

            {/* Check-In Register CTA */}
            <button
              onClick={() => {
                setVisitorToEdit(null);
                setIsCheckInOpen(true);
              }}
              className="py-2.5 px-4 bg-[#005DA6] hover:bg-[#004070] active:bg-[#003056] text-white rounded-none font-bold text-xs flex items-center gap-2 border-b-2 border-r-2 border-[#FFD500] shadow-sm transition-all uppercase tracking-wider cursor-pointer"
            >
              <PlusCircle size={15} />
              <span className="hidden sm:inline">Daftarkan Tamu</span>
              <span className="sm:hidden">Daftar</span>
            </button>

          </div>
        </div>
      </header>

      {/* Main Container Workspace */}
      <main className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-3 pb-12 flex-1 min-w-0 flex flex-col max-w-full">
        
        {/* Welcome Banner Card (Geometric Balance Theme) */}
        {isBannerVisible && (
          <div className="mb-3 p-3.5 bg-white dark:bg-[#111c30] border-2 border-slate-200 dark:border-slate-800 rounded-none flex flex-col md:flex-row items-start md:items-center justify-between gap-3 shadow-[2px_2px_0px_rgba(0,93,166,0.06)] transition-all flex-shrink-0 relative">
            <button 
              onClick={() => setIsBannerVisible(false)}
              className="absolute top-2 right-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 p-1 cursor-pointer transition-colors"
              title="Sembunyikan Informasi"
            >
              <X size={14} />
            </button>
            <div className="flex gap-3 pr-4">
              <div className="p-2.5 bg-sky-50 dark:bg-sky-950/40 rounded-none text-[#005DA6] self-start md:self-center border border-sky-100 dark:border-sky-900 flex-shrink-0">
                <BookOpen size={20} />
              </div>
              <div>
                <h2 className="text-sm font-black tracking-tight text-slate-900 dark:text-white leading-none font-display">
                  Selamat Datang di SIMATA (Sistem Informasi Manajemen Tamu)
                </h2>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 max-w-4xl leading-relaxed">
                  Sistem pencatatan digital tamu PT PLN (Persero). Daftarkan tamu, berikan Gate Pass, cetak kartu bukti pengenal, dan pantau durasi secara otomatis demi menjaga tingkat keamanan instalasi vital PLN.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <button 
                onClick={() => setIsSopOpen(true)}
                className="px-3.5 py-1.5 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-600 dark:text-slate-300 font-bold text-[10px] rounded-none border border-slate-200 dark:border-slate-705 flex items-center gap-1.5 transition-all text-center uppercase tracking-wider cursor-pointer"
              >
                <Info size={12} className="text-[#005DA6]" />
                Manual SOP Keamanan
              </button>
            </div>
          </div>
        )}

        {/* Dynamic Statistics KPIs Row (Synchronized automatically to current state) */}
        <div className="flex-shrink-0">
          <StatsDashboard visitors={visitors} />
        </div>

        {/* Navigation Tabs (SIMATA Workspace Deck) */}
        <div className="mb-3 border-b-2 border-slate-200 dark:border-slate-800 flex items-center justify-start gap-1 select-none flex-shrink-0">
          <button
            onClick={() => setCurrentTab('buku-tamu')}
            className={`px-5 py-2.5 text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2 border-t-2 border-l-2 border-r-2 cursor-pointer ${
              currentTab === 'buku-tamu'
                ? 'bg-white dark:bg-[#111c30] text-[#005DA6] dark:text-[#FFD500] border-t-2 border-r-2 border-l-2 border-[#005DA6] dark:border-[#005DA6] -mb-[2px] z-10 font-black'
                : 'bg-slate-100 dark:bg-slate-900/40 text-slate-500 border-transparent hover:text-slate-700 dark:hover:text-slate-300'
            }`}
          >
            <UserCheck2 size={13} />
            Buku Tamu Aktif
          </button>
          
          <button
            onClick={() => setCurrentTab('notifikasi')}
            className={`px-5 py-2.5 text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2 border-t-2 border-l-2 border-r-2 cursor-pointer relative ${
              currentTab === 'notifikasi'
                ? 'bg-white dark:bg-[#111c30] text-[#005DA6] dark:text-[#FFD500] border-t-2 border-r-2 border-l-2 border-[#005DA6] dark:border-[#005DA6] -mb-[2px] z-10 font-black'
                : 'bg-slate-100 dark:bg-slate-900/40 text-slate-500 border-transparent hover:text-slate-700 dark:hover:text-slate-300'
            }`}
          >
            <Bell size={13} />
            Notifikasi Cerdas
            {notifications.length > 0 && (
              <span className="ml-1.5 px-1.5 py-0.5 flex items-center justify-center bg-rose-500 text-white rounded-none text-[8.5px] font-black border border-white dark:border-[#111c30] leading-none">
                {notifications.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setCurrentTab('laporan')}
            className={`px-5 py-2.5 text-xs font-black uppercase tracking-wider transition-all flex items-center gap-2 border-t-2 border-l-2 border-r-2 cursor-pointer ${
              currentTab === 'laporan'
                ? 'bg-white dark:bg-[#111c30] text-[#005DA6] dark:text-[#FFD500] border-t-2 border-r-2 border-l-2 border-[#005DA6] dark:border-[#005DA6] -mb-[2px] z-10 font-black'
                : 'bg-slate-100 dark:bg-slate-900/40 text-slate-500 border-transparent hover:text-slate-700 dark:hover:text-slate-300'
            }`}
          >
            <BarChart2 size={13} />
            Laporan & Metrik
          </button>
        </div>

        {/* Dynamic Interactive Visitor logs Table */}
        <div className="w-full max-w-full min-w-0 flex flex-col">
          {currentTab === 'buku-tamu' && (
            <div className="w-full max-w-full min-w-0 flex flex-col">
              <div className="flex items-center justify-between mb-2.5 px-1 flex-shrink-0">
                <div>
                  <h3 className="font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2 font-display uppercase text-xs">
                    <span className="inline-block w-1 h-3.5 bg-[#005DA6] dark:bg-[#FFD500]"></span>
                    Daftar Buku Tamu Aktif & Terjadwal
                  </h3>
                  <p className="text-[9.5px] text-slate-400 mt-0.5">
                    Urutkan log berdasarkan Form ID atau status tamu secara instan
                  </p>
                </div>
                {/* Realtime stats count badge */}
                <div className="flex gap-2 flex-shrink-0">
                  <span className="px-2.5 py-1 bg-[#005DA6] text-white border-b border-r border-[#FFD500] rounded-none text-[9px] font-black uppercase tracking-wide font-mono">
                    {visitors.length} Registrasi
                  </span>
                </div>
              </div>

              <VisitorTable
                visitors={visitors}
                onCheckOut={handleCheckOut}
                onCheckOutBatch={handleCheckOutBatch}
                onEdit={(visitor) => {
                  setVisitorToEdit(visitor);
                  setIsCheckInOpen(true);
                }}
                onDelete={handleDeleteVisitor}
                onViewBadge={(visitor) => {
                  setVisitorForBadge(visitor);
                }}
                onAddSampleData={handleAddSampleVisitor}
              />
            </div>
          )}

          {currentTab === 'notifikasi' && (
            <div className="w-full">
              <NotificationCenter
                notifications={notifications}
                onClearAll={handleClearAllNotifications}
                onResend={handleResendNotification}
              />
            </div>
          )}

          {currentTab === 'laporan' && (
            <div className="w-full">
              <ReportModule
                visitors={visitors}
              />
            </div>
          )}
        </div>

      </main>

      {/* Slim Footer Row inside application wrapper */}
      <footer className="bg-white dark:bg-[#111c30]/80 border-t border-slate-250 dark:border-slate-850 py-2.5 text-center text-[10px] text-slate-400 font-sans flex-shrink-0 select-none transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2.5">
          <p className="font-semibold text-slate-500 dark:text-slate-400">
            &copy; 2026 PT PLN (Persero). SIMATA — Sistem Informasi Manajemen Tamu. All rights reserved.
          </p>
          <div className="flex gap-4 font-mono text-[9px]">
            <span>Version 3.0.12 (Stable)</span>
            <span>&bull;</span>
            <span>Security Server: GI-PLN-ACTIVE</span>
          </div>
        </div>
      </footer>

      {/* Dynamic Popups Framework */}
      
      {/* Brand Theme Harmony Studio Modal */}
      {isThemeStudioOpen && (
        <ThemeStudioModal
          isOpen={isThemeStudioOpen}
          onClose={() => setIsThemeStudioOpen(false)}
          currentTheme={currentTheme}
          onChangeTheme={(theme) => setCurrentTheme(theme)}
          darkMode={darkMode}
          onChangeDarkMode={(isDark) => setDarkMode(isDark)}
          bgStyle={bgStyle}
          onChangeBgStyle={(style) => setBgStyle(style)}
          triggerToast={triggerToast}
        />
      )}

      {/* Check-In / Edit Registration Modal */}
      {isCheckInOpen && (
        <CheckInModal
          visitorToEdit={visitorToEdit}
          onSave={handleSaveVisitor}
          onClose={() => {
            setIsCheckInOpen(false);
            setVisitorToEdit(null);
          }}
          visitorsCount={visitors.length}
          lastFormId={lastFormId}
        />
      )}

      {/* Guest Card Pass / Printer Mockup Badge Modal */}
      {visitorForBadge && (
        <BadgeModal
          visitor={visitorForBadge}
          onClose={() => setVisitorForBadge(null)}
        />
      )}

      {/* Safety & SOP Reference area Modal */}
      {isSopOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fade-in" id="sop-modal">
          <div className="bg-white dark:bg-[#111c30] border-2 border-[#005DA6] dark:border-[#FFD500] rounded-none p-6 shadow-xl max-w-xl w-full relative">
            <button 
              onClick={() => setIsSopOpen(false)}
              className="absolute top-3 right-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 font-extrabold cursor-pointer transition-colors"
            >
              <X size={18} />
            </button>
            
            <div className="flex items-center gap-2.5 text-slate-900 dark:text-white mb-4 border-b border-slate-100 dark:border-slate-800 pb-3">
              <ShieldAlert className="text-[#005DA6] dark:text-[#FFD500]" size={20} />
              <h4 className="font-sans font-black text-xs tracking-wider uppercase">SOP Keamanan & Penerimaan Tamu PLN</h4>
            </div>

            <div className="space-y-4 text-xs text-slate-600 dark:text-slate-400 max-h-[70vh] overflow-y-auto pr-2">
              <div className="space-y-1.5">
                <h5 className="font-extrabold text-slate-900 dark:text-slate-250 uppercase tracking-wider text-[11px] border-l-2 border-[#005DA6] pl-2 flex items-center gap-2">
                  <UserCheck2 size={12} className="text-[#005DA6] dark:text-sky-350" />
                  1. Verifikasi Identitas Utama
                </h5>
                <p className="leading-relaxed pl-2.5">
                  Tamu wajib menyerahkan kartu identitas resmi (KTP atau SIM) di pos penjagaan utama. Petugas berkewajiban mencocokkan wajah tamu dengan foto yang tertera pada kartu identitas sebelum mendaftarkan data ke sistem SIMATA.
                </p>
              </div>
              
              <div className="space-y-1.5">
                <h5 className="font-extrabold text-slate-900 dark:text-slate-250 uppercase tracking-wider text-[11px] border-l-2 border-[#005DA6] pl-2 flex items-center gap-2">
                  <ShieldAlert size={12} className="text-[#005DA6] dark:text-sky-350" />
                  2. Akses & Pemberian Gate Pass
                </h5>
                <p className="leading-relaxed pl-2.5">
                  Petugas wajib memberikan kartu akses fisik (Gate Pass) yang nomornya dicatat dalam kolom <strong>Main Gate Pass</strong>. Tamu wajib mengalungkan kartu pass masuk tersebut demi kenyamanan identifikasi pengawasan di lingkungan PLN.
                </p>
              </div>

              <div className="space-y-1.5">
                <h5 className="font-extrabold text-slate-900 dark:text-slate-250 uppercase tracking-wider text-[11px] border-l-2 border-[#005DA6] pl-2 flex items-center gap-2">
                  <BookOpen size={12} className="text-[#005DA6] dark:text-sky-350" />
                  3. Proses Check-Out & Pengembalian
                </h5>
                <p className="leading-relaxed pl-2.5">
                  Ketika kunjungan selesai, tamu harus diarahkan untuk menyerahkan kembali Gate Pass kepada petugas resepsionis. Petugas wajib menekan tombol <strong>Check-Out</strong> di baris nama tamu dalam sistem SIMATA untuk mendokumentasikan jam kepulangan secara akurat.
                </p>
              </div>
            </div>

            <div className="mt-6 pt-3.5 border-t border-slate-100 dark:border-slate-800 flex justify-end">
              <button 
                onClick={() => setIsSopOpen(false)}
                className="px-4 py-2 bg-[#005DA6] hover:bg-[#004070] text-white font-bold text-xs uppercase tracking-wider border-b-2 border-r-2 border-[#FFD500] cursor-pointer transition-colors"
              >
                Saya Mengerti & Siap Melaksanakan SOP
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
